package defaultpack;
import java.util.HashMap;
import java.util.Map;

public class Inventory
{
			private HashMap<Integer,Item> hm=new HashMap<Integer,Item>();
			public HashMap<Integer, Item> getHm() 
			{
					return hm;
			}
			public void setHm(HashMap<Integer, Item> hm) 
			{
					this.hm = hm;
			}
			public void addItem(int k,Item i) 
			{
				if(hm.containsKey(k))
						throw new IllegalArgumentException(k + " ITEM ALREADY PRESENT IN INVENTORY.");
				else
					{	
						hm.put(k, i);
						for(Map.Entry<Integer, Item> h : hm.entrySet())
							{
								Item inew =h.getValue();
								System.out.println(inew);
							}
							System.out.println("NEW ITEM ADDED TO THE INVENTORY.");
					}
			  }
			public void updateQuantity(int k,int newQuan)
			{
					if(hm.containsKey(k))
						{
							Item i =hm.get(k);
							i.quantity=newQuan;
							System.out.println("QUANTITY SUCCESSFULLY UPDATED.");
						}
					else
						throw new IllegalArgumentException(k + " NO. ITEM IS NOT THERE IN INVENTORY. ");
			}	
			public Item retrieveItem(int rtv) 
			{
					if(hm.get(rtv)==null)
						throw new IllegalArgumentException(rtv + " ITEM IS NOT PRESENT. ");
					else
						return hm.get(rtv);
			}
			public void removeItem(int k) 
			{
					hm.remove(k);
					System.out.println("ITEM REMOVED SUCCESSFULLY.");
			}				
}