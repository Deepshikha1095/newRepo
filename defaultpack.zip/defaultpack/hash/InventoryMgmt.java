package defaultpack;
import java.util.HashMap;
import java.util.Scanner;

public class InventoryMgmt
{
		public static void main(String[] args)
		{
			Inventory inv=new Inventory();
			HashMap<Integer,Item> hm=inv.getHm();
			hm.put(1, new Item(1,"Glass",100,100.0));
			hm.put(2, new Item(2,"Plate",200,200.0));
			hm.put(3, new Item(3,"Spoon",50,50.0));
			Scanner sc=new Scanner(System.in);
			boolean isUserActive=true;
		while(isUserActive)
		{
			System.out.println("CHOOSE ONE-1.ADD ITEM 2.UPDATE QUANTITY 3.RETRIEVE DETAILS 4.REMOVE ITEM 5.DISPLAY INVENTORY 6.EXIT");
			int op=sc.nextInt();
			switch(op)
			{
			case 1: 
				System.out.println("ENTER KEY,ITEM ID,NAME,QAUNTITY,PRICE- ");
			 	inv.addItem(sc.nextInt(),new Item(sc.nextInt(),sc.next(),sc.nextInt(),sc.nextDouble()));
			 	break;
			 	
			case 2:System.out.println("ENTER ITEM ID AND ITS NEW QUANTITY= ");
					inv.updateQuantity(sc.nextInt(),sc.nextInt());
					break;
			
			case 3: System.out.println("ENTER ITEM ID TO RETRIEVE DETAILS = ");
					int rtv=sc.nextInt();
					System.out.println(inv.retrieveItem(rtv));	
					break;	
				
			case 4:System.out.println("ENTER ITEM ID TO REMOVE = ");
					try{
						inv.removeItem(sc.nextInt()); 
					}
					catch(IllegalArgumentException ie)
					{
						System.out.println("ITEM ALREADY PRESENT IN INVENTORY.");
					}break;	
					
			case 5:	inv.getHm().forEach((key,value) -> System.out.println(value));
					break;
					
			case 6: System.out.println("EXIT");
					isUserActive=false;
					break;	
			default: System.out.println("INVALID INPUT");
			}	
		}
		sc.close();
		}
}