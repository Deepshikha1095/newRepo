package defaultpack;

public class Item 
{	
		int id;
		String name;
		int quantity;
		double price;
		public Item(int id, String name, int quantity, double price) 
		{
			this.id=id;
			this.name = name;
			this.quantity= quantity;
			this.price = price;
		}
		@Override
		public String toString()
		{
			return "Item [Id= " + id + ", name=" + name + ", quantity=" + quantity + ", price=" + price + "]";
		}
}