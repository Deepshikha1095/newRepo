package defaultpack;

public class Book
{
		  public String title;
		  public String  author;
		  public String ISBN;
		  public int pubYear;
		  
		  public Book(String title, String author, String ISBN, int pubYear) 
		  {
			this.title = title;
			this.author = author;
			this.ISBN = ISBN;
			this.pubYear = pubYear;
		  }
		  public String getTitle()
		  {
			  return title;
		  }
		  public String getAuthor()
		  {  
			  return author;
		  }
		  public String getISBN()
		  {
			  return ISBN;  
		  }
		  public int getPubYear()
		  {
			  return pubYear;
		  }
		  public String toString()
		  {
			  return "Title= " + title + " ,AUTHOR= " + author + " ,ISBN= " + ISBN + " ,PUBLICATION YEAR = " + pubYear;
		  }
}