package defaultpack;
import java.util.ArrayList;
import java.util.Scanner;

public class LibraryMgmtSys
{
			Scanner s = new Scanner(System.in);
			ArrayList<Book> bookCollection=new ArrayList<>();
	
			void addBook(Book book)
			{
				bookCollection.add(book);
				System.out.println("NEW BOOK SUCCESSFULLY ADDED.");
				System.out.println(book.toString());
			}
			void removeBook(String ISBN)
			{
				bookCollection.removeIf(book -> book.getISBN().equals(ISBN));
				System.out.println("BOOK REMOVED FROM LIBRARY.");
			}
			Book searchBook(String title)
			{
				for(Book book : bookCollection)
				{
					if(book.getTitle().equalsIgnoreCase(title)) {
						return book;}
				}
				return null;
			}
			void displayAllBooks()
			{	
				if(bookCollection.isEmpty())
					System.out.println("COLLECTION IS EMPTY.");
				else
					bookCollection.forEach(Book -> System.out.println(Book));
					//for(Book book:bookCollection)
					//{
						//System.out.println(book);
					//}
			}
}