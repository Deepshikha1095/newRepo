package defaultpack;
import java.util.Scanner;

public class MainBookAL 
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		LibraryMgmtSys l= new LibraryMgmtSys();
		
		Book b1=new Book("SECRET", " RHONDA BYRNE " , "97-87-2045-67",2020);
		l.bookCollection.add(b1);
		Book b2=new Book("DIPLOMACY", " HENRY KISSINGER " , "90-76-8705-11", 2024);
		l.bookCollection.add(b2);
		boolean isUserActive=true;
while(isUserActive)
{
	System.out.println("CHOOSE = 1.ADD BOOK 2.REMOVE BOOK 3.SEARCH BOOK 4. DISPLAY ALL BOOK");
		switch(s.nextInt())
		{
		case 1:	System.out.println("ENTER TITLE,AUTHOR,ISBN ,PUBLICATION YEAR= ");
				Book book=new Book(s.next(), s.next() , s.next(), s.nextInt());
				l.addBook(book);break;
				
		case 2: System.out.println("ENTER ISBN TO REMOVE= ");
				l.removeBook(s.next());
				l.displayAllBooks();break;
		
		case 3: System.out.println("ENTER BOOK TITLE TO SEARCH = ");
				Book foundBook=l.searchBook(s.next());
				if(foundBook!=null)
					System.out.println("THIS BOOK FOUND SUCCESSFULLY.");
				else
					System.out.println("THIS BOOK NOT FOUND IN LIBRARY.");
			
				break;
		case 4 : l.displayAllBooks();break;
		
		case 5: System.out.println("EXIT");
				isUserActive=false; break;
		
		default :	System.out.println("INVALID INPUT.");break;
		}
}
s.close();   
}
}