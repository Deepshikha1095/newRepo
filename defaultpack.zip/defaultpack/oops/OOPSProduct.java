package defaultpack;

abstract class OOPSProduct 
{
		public int pid;
		public String pname;
		public int price;
		public OOPSProduct(int pid,String pname,int price)
		{
			this.pid=pid;
			this.pname=pname;
			this.price=price;
		}
		void info()
		{
			System.out.println("PRODUCT DETAILS = PRODUCT ID- " + pid + " PRODUCT NAME- " + pname);	
		}
		public abstract void showPrice();
}
	class Electronics extends OOPSProduct implements ProductInterface
	{
		int warranty;
		public Electronics(int pid,String pname,int price,int warranty) 
		{
			super(pid,pname,price);
			this.warranty=warranty;
		}
		void displayProduct()
		{
		super.info();
		System.out.println("WARRANTY PERIOD IN YEARS- " + warranty);
		}
		public void showPrice()
		{
			System.out.println(pid + "costs rs = " + price);
		}
		@Override
		public void getPaymentDetails()
		{
			System.out.println("electronic payment detals");
		}
	}
	class Clothing extends OOPSProduct implements ProductInterface
	{
		int size;
		public Clothing(int pid,String pname,int price ,int size)
		{
			super(pid,pname,price);
			this.size=size;
		}
		void displayProduct()
		{
			super.info();
			System.out.println("SIZE OF CLOTH- " + size);
		}
		public void showPrice() 
		{
			System.out.println(pid + " costs rs = " + price);
		}
		@Override
		public void getPaymentDetails()
		{
			System.out.println("clothing details");
		}
	}