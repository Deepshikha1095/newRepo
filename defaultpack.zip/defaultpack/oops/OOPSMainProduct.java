package defaultpack;
import java.util.Scanner;

public class OOPSMainProduct 
{
	public static void main(String[] args)
		{
			Scanner s =new Scanner(System.in);
			System.out.println("ENTER ELECTRONIC PRODUCT ID, NAME ,WARRANTY PERIOD IN YEARS , PRICE= ");
		    Electronics e1=new Electronics(s.nextInt(),s.next(),s.nextInt(),s.nextInt()); 
		    e1.displayProduct();
		    e1.showPrice();
		    
		    System.out.println("ENTER CLOTHING PRODUCT ID, NAME ,SIZE OF CLOTH = ");
		    Clothing c1=new Clothing(s.nextInt(),s.next(),s.nextInt(),s.nextInt()); 
		    c1.displayProduct();
		    c1.showPrice();
		    s.close();
		}
}