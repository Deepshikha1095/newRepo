package defaultpack;

public interface ProductInterface 
{
		void getPaymentDetails();
}
