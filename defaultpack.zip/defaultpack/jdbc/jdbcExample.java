package defaultpack;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class jdbcExample
{	
	public PreparedStatement pmt;
	public String query;
	public Connection con;
	Scanner s = new Scanner(System.in);
	
	public Connection createConnection() throws ClassNotFoundException, SQLException 
	{
		Class.forName("com.mysql.cj.jdbc.Driver");					
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dkdb","root","DEEPSHIKHA");
		System.out.println("got the jdbc connection");    
		return con;
	}	
	public void createData(String empcode,String empname, String deptcode,int basicpay) 
			//throws NullPointerException
	{
        try{ 
        	query ="insert into emp(empcode,empname,deptcode,basicpay) values (?,?, ?, ?)";
        	pmt=con.prepareStatement(query);
            pmt.setString(1, empcode);
            pmt.setString(2, empname);
            pmt.setString(3, deptcode);
            pmt.setInt(4, basicpay);
            pmt.executeUpdate();
            System.out.println("New Employee created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //catch (NullPointerException n) {
          // System.out.println("error");
        //}
    }
	public void retrieveData() throws SQLException,NoSuchElementException
	{
		//RETRIEVE
		try{
				query ="select * from emp where deptcode = ?";
				pmt=con.prepareStatement(query);
				System.out.println("Enter dept code=");
				String  code = s.next();		  
				pmt.setString(1, code);
				ResultSet rs=pmt.executeQuery();
			while(rs.next())
				{
					System.out.println(rs.getInt("empcode")+ " "+ rs.getString("empname")+ " "+rs.getString("deptcode")+" " + rs.getInt("basicpay"));	   
				}	
			rs.close();
		}
		catch (SQLException e) { e.printStackTrace();
		}catch (NoSuchElementException el) { System.out.println("error");}
		
	}	
	public void updateData() throws SQLException
	{		   
			   //Update
		try {
			   query = "update emp set basicpay = ? where empcode = ?";
			   pmt=con.prepareStatement(query);
			   System.out.println("enter the empcode");
			   String  empcode = s.next();
			   System.out.println("enter the basicpapy");
			   int sal = s.nextInt();
			   pmt.setInt(1, sal);
			   pmt.setString(2, empcode);
			   pmt.executeUpdate();
			   System.out.println("Record updated");
		}catch (SQLException e) { e.printStackTrace();}
	}
	public void deleteData() throws SQLException 
	{
		//DELETE
	  try{
		   query ="delete from emp where empcode = ?";
		   pmt=con.prepareStatement(query);
		   System.out.println("Enter the empcode");
		   int  empcode = s.nextInt();
		   pmt.setInt(1, empcode);
           pmt.executeUpdate();
           System.out.println("Employee deleted successfully.");   
	  }
	  catch (SQLException e) { e.printStackTrace();}
	}
}