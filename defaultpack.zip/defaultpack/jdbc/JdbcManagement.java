package defaultpack;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcManagement 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		jdbcExample j1=new jdbcExample();
		j1.createConnection();
		System.out.println("ENTER CHOICE=1.Add employee \n2.Display Details \n3.Update Employee \n4. Delete Employee \n5.EXIT");
		Scanner s=new Scanner(System.in);
		int ch=s.nextInt();
		
		switch(ch)
		{
		case 1: j1.createData("7","Deepshii", "700", 90000);break;
		
		case 2:	j1.retrieveData();break;
		
		case 3:	j1.updateData();break;
		
		case 4: j1.deleteData();break;
		
		case 5:	System.out.println("EXIT.");
				break;
				
		default: System.out.println("INVALID INPUT.");
    			break;		
		}
		s.close();
	 
	}  
}