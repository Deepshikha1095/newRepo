package defaultpack;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class FileManager 
{
   //WRITING LIST OF PERSON OBJEECTS TO FILE
			public static void writePersons(List<Person> persons, String fileName) 
				{
					try 
					{
						ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName));
						oos.writeObject(persons);
						System.out.println("NEW PERSON ADDED TO FILE " + fileName);
						oos.close();				
					} catch (IOException e)
					{
						System.out.println("ERROR " + e.getMessage());
					}
					catch (NoSuchElementException e) {System.out.println("NO SUCH ELEMENT FOUND.");}
				}
			  // READING LIST OF PERSON OBJECTS FROM FILE
			@SuppressWarnings("unchecked")
			public static List<Person> readPersons(String fileName) 
				{
					List<Person> persons=new ArrayList<>();
					try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) 
					{
						persons=(List<Person>) ois.readObject();
						System.out.println("PERSONS LOADED FROM FILE.");
					} 
					catch (FileNotFoundException e) 
					{
						 System.out.println("FILE DO NOT FOUND " + fileName);
						        
					} catch (IOException | ClassNotFoundException | ClassCastException e)
					{
						 System.out.println("ERROR READING FROM THE FILE " + e.getMessage());
					}
					return persons;
				}
			//DISPLAYING PERSONS OBJECT
			public static void displayPersons(List<Person> persons) 
				{
					if (persons.isEmpty()) 
					{
						  System.out.println("FILE IS EMPTY.");
					} 
					else 
					{
						  persons.forEach(System.out::println);
					}
				}
				  // SEARCHING PERSON BY NAME
			public static Person findPersonByName(List<Person> persons, String name) 
				 {
					 for (Person person : persons) 
					 {
						 if (person.getName().equalsIgnoreCase(name)) 
						 {
						      return person;
						  }
					 }
					 System.out.println("PERSON'S DETAILS DO NOT EXIST IN FILE ");
					 return null;
				 }
	public static void main(String[] args)
	{
			    List<Person> persons = new ArrayList<>();
			    Person p1=new Person("RAM",22,"ram.kumar@gmail.com");
			    Person p2=new Person("SHYAM",30,"shyam.kumar@gmail.com");
			    persons.add(p1);
			    persons.add(p2);
			    boolean isUserActive=true;
			    Scanner sc = new Scanner(System.in);
	     while(isUserActive)
	     	{
			    System.out.println("CHHOSE ONE-\n1.ADD NEW PERSON");
			     System.out.println("2.SAVE PERSON TO FILE");
			     System.out.println("3.LOAD PERSONS FROM FILE");
			     System.out.println("4.DISPLAY");
			     System.out.println("5.FIND PERSON BY NAME");
			     System.out.println("6.EXIT");
			     switch(sc.nextInt())
			     {
			                case 1: // Adding new person
			                    System.out.print("ENTER NAME= ");
			                    String name = sc.next();
			                    sc.nextLine(); 
			                    System.out.print("ENTER AGE="); 
			                    int age = sc.nextInt();
			                    sc.nextLine(); // Consume newline
			                    System.out.print("ENTER EMAIL=");
			                    String email = sc.nextLine();
			                    persons.add(new Person(name, age, email));
			                    System.out.println(name + " PERSON ADDED TO LIST SUCCESSFULLY.");
			                    displayPersons(persons);
			                    break;
			                case 2:// Save persons to file
			                	writePersons(persons,"DEEPSHfile.txt");
			                    break;
			                case 3:// Load persons from file
			                    persons = readPersons("DEEPSHfile.txt");
			                    displayPersons(persons);
		                		break;    
			                case 4:
			                	displayPersons(persons);
			                    break;
			                case 5:
			                	System.out.println("ENTER NAME OF THE PERSON TO FIND=");
			                    Person foundPerson =findPersonByName(persons,sc.next());
			                    System.out.println(foundPerson);
			                    break;
			                case 6:
			                    System.out.println("EXIT.");
			                    isUserActive=false;
			                    break;
			                default:
			                    System.out.println("INVALID INPUT.");
			                    break;
			       }
	     	}
	     sc.close();
		}
}
